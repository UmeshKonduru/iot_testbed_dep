import socket
import random
import struct
import time
import threading

PACKET_SIZE = 8
TIMEOUT = 2
SERVER_ADDRESS = ('localhost', 8080)

def generate_checksum(data):
    return sum(data) % 65536

def create_packet(data, seq_num, flag):
    checksum = generate_checksum(data + [seq_num, flag])
    return struct.pack('4sBBH', bytes(data), seq_num, flag, checksum)

def parse_packet(packet):
    data, seq_num, flag, checksum = struct.unpack('4sBBH', packet)
    return list(data), seq_num, flag, checksum

def introduce_error(packet):
    packet = bytearray(packet)
    for i in range(len(packet)):
        for j in range(8):
            if random.random() < 0.01:
                packet[i] ^= (1 << j)
    return bytes(packet)

def RDT_send(sock, data):
    seq_num = 0
    for i in range(0, len(data), 4):
        packet_data = data[i:i+4]
        packet = create_packet(packet_data, seq_num, 1)
        while True:
            print(f"Client: Sending packet [seq_num {seq_num}, data {packet_data}, checksum {generate_checksum(packet_data + [seq_num, 1])}]")
            UDT_send(sock, packet)
            sock.settimeout(TIMEOUT)
            try:
                ack_packet, _ = sock.recvfrom(PACKET_SIZE)
                ack_data, ack_seq_num, ack_flag, ack_checksum = parse_packet(ack_packet)
                if ack_flag == 2 and ack_seq_num == seq_num:
                    print(f"Client: Received ACK for packet with seq_num {seq_num}")
                    seq_num = 1 - seq_num
                    break
                else:
                    print(f"Client: Received NAK or incorrect ACK for packet with seq_num {seq_num}")
            except socket.timeout:
                print(f"Client: Timeout for packet with seq_num {seq_num}, retransmitting...")

def UDT_send(sock, packet):
    packet = introduce_error(packet)
    sock.sendto(packet, SERVER_ADDRESS)

def UDT_recv(sock):
    packet, addr = sock.recvfrom(PACKET_SIZE)
    packet = introduce_error(packet)
    return packet, addr

def RDT_recv(sock):
    expected_seq_num = 0
    while True:
        packet, addr = UDT_recv(sock)
        data, seq_num, flag, checksum = parse_packet(packet)
        if(random.random() < 0.3): continue
        if flag == 1 and generate_checksum(data + [seq_num, flag]) == checksum:
            if seq_num == expected_seq_num:
                print(f"Server: Received valid packet [seq_num {seq_num}, data {data}, checksum {checksum}]")
                ack_packet = create_packet([0, 0, 0, 0], seq_num, 2)
                sock.sendto(ack_packet, addr)
                expected_seq_num = 1 - expected_seq_num
            else:
                print(f"Server: Received out-of-order packet with seq_num {seq_num}")
        else:
            print(f"Server: Received corrupted packet [seq_num {seq_num}, data {data}, checksum {generate_checksum(data + [seq_num, flag])}]")
            nak_packet = create_packet([0, 0, 0, 0], seq_num, 3)
            sock.sendto(nak_packet, addr)

def generate_random_data():
    return [random.randint(0, 255) for _ in range(40)]

def client():
    data = generate_random_data()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    RDT_send(sock, data)
    sock.close()

def server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(SERVER_ADDRESS)
    RDT_recv(sock)
    sock.close()

server_thread = threading.Thread(target=server)
client_thread = threading.Thread(target=client)

server_thread.start()
time.sleep(1)
client_thread.start()

server_thread.join()
client_thread.join()